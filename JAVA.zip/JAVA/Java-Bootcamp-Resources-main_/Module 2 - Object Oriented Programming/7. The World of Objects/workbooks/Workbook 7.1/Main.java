import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Person Alex =new Person();

        Alex.name = "Alex";// a String
        Alex.nationality ="Albanian"; // a String
        Alex.dateOfBirth ="22.10.1994"; // a String
        Alex.passport =new String[] {Alex.name,Alex.nationality,Alex.dateOfBirth};
        // Array that stores: {person.name, person.nationality, person.dateOfBirth}
        Alex.seatNumber = 3;// an Integer

        System.out.println(Alex.name);  
        System.out.println(Alex.nationality);  
        System.out.println(Alex.dateOfBirth);
        System.out.println(Arrays.toString(Alex.passport));
        System.out.println(Alex.seatNumber);




    }
    

}
