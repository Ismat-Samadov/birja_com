package constants;

public enum Transaction {
    DEPOSIT, WITHDRAWAL;
}
