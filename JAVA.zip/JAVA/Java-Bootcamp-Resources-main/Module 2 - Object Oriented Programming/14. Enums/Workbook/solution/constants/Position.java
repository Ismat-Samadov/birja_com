package constants;

public enum Position {
    SHOOTING_GUARD, SMALL_FORWARD, POWER_FORWARD, CENTER, POINT_GUARD
}