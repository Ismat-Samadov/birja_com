public class Detention {
    public static void main(String[] args) {

        //what Bart did so far
        System.out.println("I will not copy and paste code.");
        System.out.println("I will use Camel Case when writing class names.");
        System.out.println("I will use lower Camel Case when writing function names.");
        System.out.println("I will use lower Camel Case when writing variables names.\n");

        // Task 2 – call the function 6 times. 
   }



    //Task 1 - Make a function here. See the doc comment for details. 

    /**    
      * Funtion name: printLines
      *
      * Inside the function:
      *   1. prints the four lines       
      */


}
