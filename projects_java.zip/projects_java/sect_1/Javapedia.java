import java.util.Arrays;
import java.util.Scanner;

public class Javapedia {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("\n**********Javapedia**********");
        System.out.println("How many historical figures will you register?");
        //Task 1 – Ask the user: how many historical figures will you register?
        //       – Store the value.
        int userResponse =scan.nextInt();

        String [][] array =new String[userResponse][3];

        for (int i =0 ;i<array.length;i ++){              
                            System.out.println("\n\tFigure " + (i+1));
                            scan.nextLine();

                            System.out.print("\t - Name: ");
                            array[i][0] =scan.nextLine();

                            System.out.print("\t - Date of birth: ");
                            array[i][1] =scan.nextLine();

                            System.out.print("\t - Occupation: ");
                            array[i][2] =scan.nextLine();                                  

                            System.out.print("\n");                
                                            }


        System.out.println("These are the values you stored:"); 
        print2DArray(array);



        System.out.print("\nWho do you want information on? ");  
        
        /*Task 5: Let the user search the database by name. 
            If there's a match:
              print(    tab of space    Name: <name>)
              print(    tab of space    Date of birth: <date of birth>)
              print(    tab of space    Occupation: <occupation>)

        */  
        // for (int i=0;i<array.length;i++){
        //     for (int j=0; j<array[i].length; j++)
        //                     {
        //                         if(array[i][j].equals(scan.nextLine())){
        //                             System.out.print(Arrays.toString(array[i]) + " ");
        //                             break;
        //                         }
        //                     }   
        //              }  
                     
                     
                     for (int i = 0; i<array.length;i++){
                             if (array[i][0].equals(scan.nextLine()))
                            {
                                System.out.print("Name: "); 
                                System.out.println(array[i][0]);

                                System.out.print("Date of birth: ");
                                System.out.println(array[i][1]);

                                System.out.print("Occupation: ");
                                System.out.println(array[i][2]);
                            }
                            
                                          }

        scan.close();
    }
    
    public static void print2DArray(String [] [] array){
        for (int i = 0; i<array.length;i++){     
                        for (int j=0; j<array[i].length; j++)
                            {
                                System.out.print(array[i][j] + " ");
                            }
                            System.out.print("\n");
                                         }
                            }
}
