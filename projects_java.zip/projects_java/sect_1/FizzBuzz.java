public class FizzBuzz {
    public static void main(String[] args) {
        Func_fizzbuzz(0,18);
    }
public static void Func_fizzbuzz(int start_number,int end_number)
{   int i;
    for (i = start_number; i<= end_number ;i++)
    {
        if ((i%5==0) && (i%3 ==0)){System.out.println(i + " FizzBuzz");}
            else if (i%5==0){System.out.println(i + " Buzz");}
            else if (i%3 ==0){System.out.println(i + " Fizz");}
            else {System.out.println(i + " none");}
    }
}
}
