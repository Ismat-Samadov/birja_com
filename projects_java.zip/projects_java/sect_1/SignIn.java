import java.util.Scanner;
public class SignIn {
    public static void main(String[] args) {
        
        String username = "Samantha";
        String password = "Java <3";
        String usernameEntry = " "; 
        String passwordEntry = " ";
        Scanner scan = new Scanner(System.in);
        System.out.println("\nWelcome to Javagram! Sign in below\n");
        
        while 
        ((!username.equals(usernameEntry))||(!password.equals(passwordEntry)))
            {
        System.out.print("- Username: ");
        usernameEntry = scan.nextLine();
        System.out.print("- Password: ");
        passwordEntry = scan.nextLine(); 
        System.out.println("\nIncorrect, please try again!\n");
        System.out.print("- Username: " + usernameEntry);        
        System.out.print("- Password: " + passwordEntry);
        }     
        System.out.println("\t\nWelcome");
        scan.close();   
    }
}
