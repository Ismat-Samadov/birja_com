import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Pokerito {
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        System.out.println(">>Let's play Pokerito. Type anything when you're ready.");
        scan.nextLine();
        System.out.println(">>It's like Poker, but a lot simpler.");
        System.out.println(">> • There are two players, you and the computer.");
        System.out.println(">> • The dealer will give each player one card.");
        System.out.println(">> • Then, the dealer will draw five cards (the river)");
        System.out.println(">> • The player with the most river matches wins!");
        System.out.println(">> • If the matches are equal, everyone's a winner!");
        System.out.println(">> • Ready? Type anything if you are.");
       
       
        String user_card =random_cards(rng()); 
        System.out.println("Here's your card:\n" +user_card);
        String computer_card =random_cards(rng()); 
        System.out.println("Here's the computer's card:\n" + computer_card);

        int yourMatches = 0;
        int computerMatches =0;
        System.out.println("Now, the dealer will draw five cards. Press enter to continue.");

        scan.nextLine();
        String card_1 =random_cards(rng());
        System.out.println("\nCard 1\n " + card_1);

        scan.nextLine();
        String card_2 = random_cards(rng());
        System.out.println("\nCard 2\n " + card_2);

        scan.nextLine();
        String card_3 =random_cards(rng());
        System.out.println("\nCard 3\n " + card_3);

        scan.nextLine();
        String card_4 =random_cards(rng());
        System.out.println("\nCard 4\n " + card_4);

        scan.nextLine();
        String card_5 =random_cards(rng());
        System.out.println("\nCard 5\n " + card_5);

        if 
        (user_card == card_1){yourMatches++;}
        else if 
        (user_card == card_2){yourMatches++;}
        else if 
        (user_card == card_3){yourMatches++;}
        else if 
        (user_card == card_4){yourMatches++;}
        else if 
        (user_card == card_5){yourMatches++;}
        else {yourMatches = 0;}

        if 
        (computer_card == card_1){computerMatches++;}
        else if 
        (computer_card == card_2){computerMatches++;}
        else if 
        (computer_card == card_3){computerMatches++;}
        else if 
        (computer_card == card_4){computerMatches++;}
        else if 
        (computer_card == card_5){computerMatches++;}
        else 
        {computerMatches = 0;}
    
    System.out.println("Your number of matches: " + yourMatches);
    System.out.println("Computer number of matches: " + computerMatches);

    if (yourMatches>computerMatches) {
        System.out.println("You win!");
    }

    else if (yourMatches>computerMatches){
        System.out.println("he computer wins!");
    }
    else if ((computerMatches+yourMatches )== 0)
    {
        System.out.println("everyone lose!");
    }
    else if (yourMatches==computerMatches) {
        System.out.println("everyone wins!");
    }
   
    else {
        System.out.println("Unknown exception");
    }
       
    scan.nextLine();
}

    public static int rng()
                            {
        Random ran = new Random();
        int rng_n;
        rng_n = ran.nextInt((13 - 1) + 1) + 1;
    return (int) rng_n;
                            }

    public static String random_cards(int number)
    {
        String card = " ";
   switch (number)
   {
    case 1:           
     card =
    "   _____\n"+
    "  |A _  |\n"+ 
    "  | ( ) |\n"+
    "  |(_'_)|\n"+
    "  |  |  |\n"+
    "  |____V|\n";
    break;
        
   case 2:
    card = 
    "   _____\n"+              
    "  |2    |\n"+ 
    "  |  o  |\n"+
    "  |     |\n"+
    "  |  o  |\n"+
    "  |____Z|\n";
    break;
    

    case 3:
     card =
    "   _____\n" +
    "  |3    |\n"+
    "  | o o |\n"+
    "  |     |\n"+
    "  |  o  |\n"+
    "  |____E|\n";
    break;


    case 4:
    card =
    "   _____\n" +
    "  |4    |\n"+
    "  | o o |\n"+
    "  |     |\n"+
    "  | o o |\n"+
    "  |____h|\n";
    break;

    case 5:
    card =    
    "   _____ \n" +
    "  |5    |\n" +
    "  | o o |\n" +
    "  |  o  |\n" +
    "  | o o |\n" +
    "  |____S|\n";
    break;

    case 6:
    card =
    "   _____ \n" +
    "  |6    |\n" +
    "  | o o |\n" +
    "  | o o |\n" +
    "  | o o |\n" +
    "  |____6|\n";
    break;

    case 7: 
    card =
    "   _____ \n" +
    "  |7    |\n" +
    "  | o o |\n" +
    "  |o o o|\n" +
    "  | o o |\n" +
    "  |____7|\n";
    break;

    case 8:
    card =
    "   _____ \n" +
    "  |8    |\n" +
    "  |o o o|\n" +
    "  | o o |\n" +
    "  |o o o|\n" +
    "  |____8|\n";
    break;
    
    case 9:
    card =
    "   _____ \n" +
    "  |9    |\n" +
    "  |o o o|\n" +
    "  |o o o|\n" +
    "  |o o o|\n" +
    "  |____9|\n"; 
    break;

    case 10:
    card =
    "   _____ \n" +
    "  |10  o|\n" +
    "  |o o o|\n" +
    "  |o o o|\n" +
    "  |o o o|\n" +
    "  |___10|\n";
    break;

    case 11:
    card =
    "   _____\n" +
    "  |J  ww|\n"+ 
    "  | o {)|\n"+ 
    "  |o o% |\n"+ 
    "  | | % |\n"+ 
    "  |__%%[|\n";
    break;

    case 12:
    card =
    "   _____\n" +
    "  |Q  ww|\n"+ 
    "  | o {(|\n"+ 
    "  |o o%%|\n"+ 
    "  | |%%%|\n"+ 
    "  |_%%%O|\n";
    break;

    case 13:    
    card =
    "   _____\n" +
    "  |K  WW|\n"+ 
    "  | o {)|\n"+ 
    "  |o o%%|\n"+ 
    "  | |%%%|\n"+ 
    "  |_%%%>|\n"; 
    break;
    }
return card;
}

}
