public class Beer {public static void main(String[] args) {
    name_of_func();
}
public static void name_of_func()
{   int i;
    for (i =1;i <=100; i++)
    {
    System.out.println( i + " bottles of beer on the wall, " + i + " bottles of beer!");
    System.out.println("take one down, pass it around "+(i-1)+ " , bottles of beer on the wall!");
    }
}
}
