import java.util.Scanner;

public class CounterTool {
    public static void main(String[] args)
     {
        Scanner scan = new Scanner(System.in);
        System.out.println("I hear you like to count by threes\n");
        System.out.println("Jimmy: It depends.");
        System.out.println("Oh, ok...");
        int multiply_by = scan.nextInt();
        int start_from_this_number = scan.nextInt();
        int untill_this_number = scan.nextInt();
        System.out.println("\nPick a number to count by: "+ multiply_by);
        System.out.println("\nPick a number to start counting from: "+ start_from_this_number);
        System.out.println("\nPick a number to count to: " + untill_this_number);
        scan.close();
        name_of_function(multiply_by,start_from_this_number,untill_this_number);
    }
public static void name_of_function (int multiply_by,int start_from_this_number,int untill_this_number)
{
    int i;
    for (i = start_from_this_number; i<= untill_this_number; i +=multiply_by)
    {
        System.out.println("\nYour results :" + i);
    }
}
}
