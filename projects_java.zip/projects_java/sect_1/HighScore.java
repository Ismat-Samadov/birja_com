import java.util.Arrays;

public class HighScore {
    public static void main(String[] args) {
        
        int highScore = 0;
        int[] tenElem = new int [10];

        for (
            int i = 0;i <10 ;i++
            )
                {
                    tenElem[i] = rng();
                }

        for (
            int i = 0;i <10 ;i ++
            )
                {
                    if (
                        highScore<tenElem[i]
                        )
                            {
                                highScore =tenElem[i];
                            }
                }

System.out.print("\nHere are the scores: \n" );
                for (
                    int i = 0;i <tenElem.length ;i ++
                    )
                        {
                            System.out.println("\t" + tenElem[i] + " ");
                        }

        // System.out.print("Here are the scores: <score elements>");

        System.out.println("\n\nThe highest score is: " + highScore + ". Give that man a cookie!");
        
    }    
    public static int rng (){
        double randNum = Math.random() * 5000;
        return (int) randNum;
    }
}
