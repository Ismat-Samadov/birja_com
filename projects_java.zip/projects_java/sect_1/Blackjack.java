import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Blackjack {

    public static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("\nWelcome to Java Casino!");
        System.out.println("Do you have a knack for Black Jack?");
        System.out.println("We shall see..");
        System.out.println("..Ready? Press anything to begin!");

        scan.nextLine();

        String playerCard1 = random_cards();
        String playerCard2 = random_cards();
        int total = (handValue(playerCard1) + handValue(playerCard2));
        int dealersTotal = 0;
        System.out.println("\n You get a \n" + playerCard1 + "\n and a \n" + playerCard2);

        System.out.println("your total is: " + total);

        String dealersFirstCard = random_cards();
        String dealersSecondCard = random_cards();
        dealersTotal = handValue(dealersFirstCard)+handValue(dealersSecondCard);
        System.out.println("The dealer shows \n" + dealersFirstCard +
                "\nand has a card facing down \n" + faceDown());
        System.out.println("\nThe dealer's total is hidden.");

        while (true) {
            String uo = userOption();
            if (uo.equals("hit"))

            {
                String newCard = random_cards();
                total = total + handValue(newCard);
                System.out.println("\nYou get a \n" + newCard);
                System.out.println("your new total is " + total);
                if (total > 21) {
                    System.out.println("Bust! Player loses. ");
                    System.exit(0);
                } else {
                    continue;
                }
            }

            else if (uo.equals("stay"))

            {
                System.out.println("\nDealer's turn");
                System.out.println("\nThe dealer's cards are \n" +dealersFirstCard +"\n and a \n" + dealersSecondCard);
                while (true)
                {
                    String dealerCard = random_cards();
                    dealersTotal = dealersTotal + handValue(dealerCard);
                    System.out.println("\nDealer gets a\n" + dealerCard);
                    System.out.println("\nDealer's total is " + dealersTotal);
                    if (dealersTotal>21)
                    {                    
                     System.out.println("Bust! Dealer loses");

                        break;
                    }
                }
                break;
            }
        }

        scan.close();
    }

    public static String random_cards() 
    {
        Random ran = new Random();
        int rng_n;
        rng_n = ran.nextInt((13 - 1) + 1) + 1;
        String card = " ";
        switch (rng_n) {
            case 1:
                card = "   _____\n" +
                        "  |A _  |\n" +
                        "  | ( ) |\n" +
                        "  |(_'_)|\n" +
                        "  |  |  |\n" +
                        "  |____V|\n";
                break;

            case 2:
                card = "   _____\n" +
                        "  |2    |\n" +
                        "  |  o  |\n" +
                        "  |     |\n" +
                        "  |  o  |\n" +
                        "  |____Z|\n";
                break;

            case 3:
                card = "   _____\n" +
                        "  |3    |\n" +
                        "  | o o |\n" +
                        "  |     |\n" +
                        "  |  o  |\n" +
                        "  |____E|\n";
                break;

            case 4:
                card = "   _____\n" +
                        "  |4    |\n" +
                        "  | o o |\n" +
                        "  |     |\n" +
                        "  | o o |\n" +
                        "  |____h|\n";
                break;

            case 5:
                card = "   _____ \n" +
                        "  |5    |\n" +
                        "  | o o |\n" +
                        "  |  o  |\n" +
                        "  | o o |\n" +
                        "  |____S|\n";
                break;

            case 6:
                card = "   _____ \n" +
                        "  |6    |\n" +
                        "  | o o |\n" +
                        "  | o o |\n" +
                        "  | o o |\n" +
                        "  |____6|\n";
                break;

            case 7:
                card = "   _____ \n" +
                        "  |7    |\n" +
                        "  | o o |\n" +
                        "  |o o o|\n" +
                        "  | o o |\n" +
                        "  |____7|\n";
                break;

            case 8:
                card = "   _____ \n" +
                        "  |8    |\n" +
                        "  |o o o|\n" +
                        "  | o o |\n" +
                        "  |o o o|\n" +
                        "  |____8|\n";
                break;

            case 9:
                card = "   _____ \n" +
                        "  |9    |\n" +
                        "  |o o o|\n" +
                        "  |o o o|\n" +
                        "  |o o o|\n" +
                        "  |____9|\n";
                break;

            case 10:
                card = "   _____ \n" +
                        "  |10  o|\n" +
                        "  |o o o|\n" +
                        "  |o o o|\n" +
                        "  |o o o|\n" +
                        "  |___10|\n";
                break;

            case 11:
                card = "   _____\n" +
                        "  |J  ww|\n" +
                        "  | o {)|\n" +
                        "  |o o% |\n" +
                        "  | | % |\n" +
                        "  |__%%[|\n";
                break;

            case 12:
                card = "   _____\n" +
                        "  |Q  ww|\n" +
                        "  | o {(|\n" +
                        "  |o o%%|\n" +
                        "  | |%%%|\n" +
                        "  |_%%%O|\n";
                break;

            case 13:
                card = "   _____\n" +
                        "  |K  WW|\n" +
                        "  | o {)|\n" +
                        "  |o o%%|\n" +
                        "  | |%%%|\n" +
                        "  |_%%%>|\n";
                break;
        }
        return card;
    }

    public static String faceDown() 
    {
        return '\n' +
                "   _____\n" +
                "  |     |\n" +
                "  |  J  |\n" +
                "  | JJJ |\n" +
                "  |  J  |\n" +
                "  |_____|\n";
    }

    public static String userOption() 
    {
        String userInput = scan.nextLine();
        while (!userInput.equals("hit") || !userInput.equals("stay"))

        {
            System.out.println("Please write 'hit' or 'stay'");

            userInput = scan.nextLine();

            if (userInput.equals("hit") || userInput.equals("stay")) {
                break;
            }
        }

        return (String) userInput;
    }

    public static int handValue(String card) {
        switch (card) {
            case
                    "   _____\n" +
                            "  |A _  |\n" +
                            "  | ( ) |\n" +
                            "  |(_'_)|\n" +
                            "  |  |  |\n" +
                            "  |____V|\n":
                return (int) 1;

            case
                    "   _____\n" +
                            "  |2    |\n" +
                            "  |  o  |\n" +
                            "  |     |\n" +
                            "  |  o  |\n" +
                            "  |____Z|\n":
                return (int) 2;

            case
                    "   _____\n" +
                            "  |3    |\n" +
                            "  | o o |\n" +
                            "  |     |\n" +
                            "  |  o  |\n" +
                            "  |____E|\n":
                return (int) 3;

            case
                    "   _____\n" +
                            "  |4    |\n" +
                            "  | o o |\n" +
                            "  |     |\n" +
                            "  | o o |\n" +
                            "  |____h|\n":
                return (int) 4;

            case
                    "   _____ \n" +
                            "  |5    |\n" +
                            "  | o o |\n" +
                            "  |  o  |\n" +
                            "  | o o |\n" +
                            "  |____S|\n":
                return (int) 5;

            case
                    "   _____ \n" +
                            "  |6    |\n" +
                            "  | o o |\n" +
                            "  | o o |\n" +
                            "  | o o |\n" +
                            "  |____6|\n":
                return (int) 6;

            case
                    "   _____ \n" +
                            "  |7    |\n" +
                            "  | o o |\n" +
                            "  |o o o|\n" +
                            "  | o o |\n" +
                            "  |____7|\n":
                return (int) 7;

            case
                    "   _____ \n" +
                            "  |8    |\n" +
                            "  |o o o|\n" +
                            "  | o o |\n" +
                            "  |o o o|\n" +
                            "  |____8|\n":
                return (int) 8;

            case
                    "   _____ \n" +
                            "  |9    |\n" +
                            "  |o o o|\n" +
                            "  |o o o|\n" +
                            "  |o o o|\n" +
                            "  |____9|\n":
                return (int) 9;

            case
                    "   _____ \n" +
                            "  |10  o|\n" +
                            "  |o o o|\n" +
                            "  |o o o|\n" +
                            "  |o o o|\n" +
                            "  |___10|\n":
                return (int) 10;

            case
                    "   _____\n" +
                            "  |J  ww|\n" +
                            "  | o {)|\n" +
                            "  |o o% |\n" +
                            "  | | % |\n" +
                            "  |__%%[|\n":
                return (int) 10;

            case
                    "   _____\n" +
                            "  |Q  ww|\n" +
                            "  | o {(|\n" +
                            "  |o o%%|\n" +
                            "  | |%%%|\n" +
                            "  |_%%%O|\n":
                return (int) 10;

            case
                    "   _____\n" +
                            "  |K  WW|\n" +
                            "  | o {)|\n" +
                            "  |o o%%|\n" +
                            "  | |%%%|\n" +
                            "  |_%%%>|\n":
                return (int) 10;
            default:
                return 0;

        }
    }

}
