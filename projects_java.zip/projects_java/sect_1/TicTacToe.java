import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Stream;


public class TicTacToe {

    static Scanner scan = new Scanner(System.in);
    public static void main(String[] args) {
        
            System.out.println("\nLet's play tic tac toe !!!\n");
          String [] [] array = new String [3][3];    
          //populating array with loop
          for (int i= 0 ;i<array.length;i++){
            for (int j=0;j<array[i].length;j++){array[i][j] ="_" ;}}

            printBoard(array);

         
             while
             
             (true
              
            //  Arrays.asList(Stream.of(array).
            //  flatMap(Stream::of).toArray(String[]::new)).contains("_")
             )
             {
             //break conditions

              if(
                  (
                // (Arrays.asList(Stream.of(array).
                // flatMap(Stream::of).toArray(String[]::new)).contains("_")==false)|| 

              (checkWin(array)==3)

              ||(checkWin(array)==-3)
                    )
                  )
                  {break;}
              System.out.println("\nX please enter coordinates ");
              int [] xTurn = askUser(array);
              array[xTurn[0]][xTurn[1]]="x";
              printBoard(array);
  
              if(checkWin(array)==3){
                System.out.println(" X wins: "+checkWin(array));printBoard(array);break;}
              else if(checkWin(array)==-3){
                System.out.println(" O wins: "+checkWin(array));printBoard(array);break;}
              // else {
              //   System.out.println("\nnoone wins:  " + checkWin(array));
              //   }

              System.out.println("\nO please enter coordinates ");
              int [] oTurn = askUser(array);
              array[oTurn[0]][oTurn[1]]="o";
              printBoard(array);       
            }
             

            scan.close();
        }

  
public static int[] askUser(String [] [] array){
  int x;
  int y;
  int [] cord= new int [2]; 

  System.out.println("\n enter row.\n");

    x=scan.nextInt();
  
    System.out.println("\n enter column.\n\n");

    y=scan.nextInt();

  while (!array[x][y].equals("_")){
   
    System.out.print("\nThis coordinates already has been taken\n");

    System.out.println("\n enter row.\n");
    x=scan.nextInt();
  
    System.out.println("\n enter column.\n\n");
    y=scan.nextInt();
    
    cord = new int [] {x,y};
    if (Arrays.asList(Stream.of(array).
    flatMap(Stream::of).toArray(String[]::new)).contains("_")==false)
      {
        break;
      }

  }
  cord = new int [] {x,y};
  return (int []) cord ;
}

public static int checkWin(String [] [] array){
          int count = 0 ;
          for (int i = 0; i<array.length;i++){
            if(   
                 ( 
                  //checking rows
                    (
                      array[i][0].equalsIgnoreCase("x") && 
                      array[i][1].equalsIgnoreCase("x")&&
                      array[i][2].equalsIgnoreCase("x")
                    )

                  ||
                  //checking columns
                    (
                      array[0][i].equalsIgnoreCase("x") && 
                      array[1][i].equalsIgnoreCase("x")&&
                      array[2][i].equalsIgnoreCase("x")
                    )
                  ||
                  //checking left diagonal
                    (
                      array[2][0].equalsIgnoreCase("x") && 
                      array[1][1].equalsIgnoreCase("x")&&
                      array[0][2].equalsIgnoreCase("x")
                    )

                  ||
                //checking right diagonal
                    (
                      array[0][0].equalsIgnoreCase("x") && 
                      array[1][1].equalsIgnoreCase("x")&&
                      array[2][2].equalsIgnoreCase("x")
                    )
                   

                  )


            ){count++;}
            else if (
              ( 
                //checking rows
                  
                  ( 
                    array[i][0].equalsIgnoreCase("o") && 
                    array[i][1].equalsIgnoreCase("o")&&
                    array[i][2].equalsIgnoreCase("o")
                  )

                //checking columns
              
                ||
                  ( 
                    array[0][i].equalsIgnoreCase("o") && 
                    array[1][i].equalsIgnoreCase("o")&&
                    array[2][i].equalsIgnoreCase("o")
                  )
                //checking left diagonal
                 
                ||
                  ( 
                    array[2][0].equalsIgnoreCase("o") && 
                    array[1][1].equalsIgnoreCase("o")&&
                    array[0][2].equalsIgnoreCase("o")
                  )
                ||
              //checking right diagonal
                  ( 
                    array[0][0].equalsIgnoreCase("o") && 
                    array[1][1].equalsIgnoreCase("o")&&
                    array[2][2].equalsIgnoreCase("o")
                  )

                )


            ){count--;}        
            
                               }

    return (int) count;
     }

     public static void printBoard(String [] [] array){
      
      for (int i = 0; i<array.length;i++){     
        for (int j=0; j<array[i].length; j++)
            {
                System.out.print(array[i][j] + " ");
            }
            System.out.print("\n");
                         }
                             }
}
