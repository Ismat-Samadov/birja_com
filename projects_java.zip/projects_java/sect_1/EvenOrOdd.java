public class EvenOrOdd {
    public static void main(String[] args) {
        // See Learn the Part for detailed instructions.
        name_of_fucking_function(0,19,1);
    }
    public static void name_of_fucking_function (int start_number,int end_number, int step_number) 
    {int i;
        for (i =start_number;i<= end_number;i+=step_number)
        {
            if (i% 2 == 0)
            {
                System.out.println(i + ": is even");
            }
            else {
                System.out.println(i + ": is odd");
            }

        }
    }
}
