public class WeatherNetwork {
    public static void main(String[] args) {

        //See Learn the Part for the complete instructions (link in resources folder of Udemy video).  

        
        int temp = -12;  

        String forecast = "It's warm. Go outside!";

        //IF - ELSE IF - ELSE STATEMENTS HERE!
        
        //Less than or equal to -1

        if (temp<=-1){
            System.out.println("The forecast is FREEZING! Stay home!");
        }
        //Less than or equal to 10
            else if (temp <=10){
                System.out.println("The forecast is Chilly. Wear a coat!");
            }
        //Otherwise
        else {System.out.println(forecast);
        }
    }
}
