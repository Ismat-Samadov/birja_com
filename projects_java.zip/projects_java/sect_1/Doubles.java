import java.util.concurrent.ThreadLocalRandom;

public class Doubles {
    public static void main(String[] args) {

   //      See Learn the Part for instructions.
//    int dice1 ;
//    int dice2 ;
         int dice1 = rollDice();
         int dice2 = rollDice();
   
   while (dice1 != dice2)
     {   dice1 = rollDice();
         dice2 = rollDice();
         System.out.println("Dice 1 : " + dice1 +" Dice 2: " + dice2);
    }
    System.out.println("You rolled doubles! "+" Dice 1 : " + dice1 +" Dice 2: " + dice2);
    }
    public static int rollDice(){
        int dice ;
    dice = ThreadLocalRandom.current().nextInt(1, 6 + 1);
    return (int) dice ;
    }

}



// nextInt is normally exclusive of the top value,
// so add 1 to make it inclusive


