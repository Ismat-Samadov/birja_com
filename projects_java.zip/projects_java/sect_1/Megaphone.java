public class Megaphone {
    public static void main(String[] args) {
        // See Learn the Part for the instructions.
        for (int  i =1 ; i <= 10; i++){
            System.out.println(i + ": If Java was easy, they would call it Python!");
        }
    }
    
}
