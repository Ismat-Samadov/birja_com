public class Car {
    String make;
    int price;
    int year;
    String color;
    public Car(String make,int price,int year,String color){
        this.make = make;
        this.price =price;
        this.year =year;
        this.color =color;
    }
}
