import java.util.Arrays;

public class Main2 {

    public static void main(String[] args){
    
        Person adam =new Person("Adam", "Norwegian", "27.12.1985", 5);
    
        Person james =new Person("James", "Canadian", "12.03.1975", 3);
        


        

        System.out.println(adam.name);
        System.out.println(adam.nationality);
        System.out.println(adam.dateOfBirth);
        System.out.println(Arrays.toString(adam.passport));
        System.out.println(adam.seatNumber);

        System.out.println("Name: " + adam.name +
         "\n" + "Nationality: " + adam.nationality
         + "\n" + "Date of Birth: " + adam.dateOfBirth
          + "\n" + "Seat Number: " + adam.seatNumber + "\n");


    }
    
}
