public class Airline {Person[] people;

public Airline (){
    this.people =new Person[11]; 
}


}
