import smtplib
email_address = 'ismetsemedov@gmail.com'
password = 'owmcltirbhdfqidw'
to_list=['ismetsemedov@gmail.com','ismetsemedli@mail.ru','ismetsemedov@live.ru']
with smtplib.SMTP("smtp.gmail.com", 587, timeout=120) as mailServer:
    mailServer.starttls()
    mailServer.login(user =email_address ,password = password)
    mailServer.sendmail(from_addr=email_address,to_addrs=to_list,msg='Subject:Hello')
