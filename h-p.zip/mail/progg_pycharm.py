import smtplib
import datetime as dt

# date time module

# now = dt.datetime.now()
# year = now.year
# month = now.month
# weekday = now.weekday()+1
# day = now.day
# hour = now.hour
# minute =now.minute
# my_birth_date =dt.datetime(year=1994,month=10,day=22,hour=9,minute=23,second=33,microsecond=13)
# print('year :' ,year,
#       ' \n\nmonth : ',month,
#       ' \n\nweekday: ',weekday,
#       ' \n\nday: ', day,
#       ' \n\nhour : ',hour,
#       ' \n\nminute : ',minute,
#       '\n\nmy_birth_date:',my_birth_date
#       )

# emailing

# email_address = 'ismetsemedov@gmail.com'
# password = 'owmcltirbhdfqidw'
# to_list=['ismetsemedov@gmail.com','ismetsemedli@mail.ru','ismetsemedov@live.ru']
# with smtplib.SMTP("smtp.gmail.com", 587, timeout=120) as mailServer:
#     mailServer.starttls()
#     mailServer.login(user =email_address ,password = password)
#     mailServer.sendmail(from_addr=email_address,to_addrs=to_list,msg='Subject:Hello')

